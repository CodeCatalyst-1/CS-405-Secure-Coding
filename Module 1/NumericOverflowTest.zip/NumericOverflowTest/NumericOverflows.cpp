#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <string>
#include <typeinfo>
#include <cmath>        // for isnan, isinf

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="overflowed">Indicates if overflow occurred</param>
/// <returns>start + (increment * steps) or last safe value</returns>
template <typename T>
T add_numbers(T const& start, T const& increment, unsigned long int const& steps, bool& overflowed)
{
    T result = start;
    overflowed = false;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for overflow before addition
        if constexpr (std::is_integral<T>::value) // only for integer types
        {
            if (increment > 0 && result > std::numeric_limits<T>::max() - increment)
            {
                overflowed = true;
                return result; // prevent overflow
            }

            if (increment < 0 && result < std::numeric_limits<T>::min() - increment)
            {
                overflowed = true;
                return result; // prevent underflow
            }
        }

        if constexpr (std::is_floating_point<T>::value) // only for floating point types
        {
            if (std::isinf(result + increment))
            {
                overflowed = true;
                return result; // prevent overflow
            }
        }

        result += increment;
    }

    return result;
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="decrement">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="underflowed">Indicates if underflow occurred</param>
/// <returns>start - (increment * steps) or last safe value</returns>
template <typename T>
T subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, bool& underflowed)
{
    T result = start;
    underflowed = false;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Check for underflow before subtraction
        if constexpr (std::is_integral<T>::value) // only for integer types
        {
            if (decrement > 0 && result < std::numeric_limits<T>::min() + decrement)
            {
                underflowed = true;
                return result; // prevent underflow
            }
        }

        if constexpr (std::is_floating_point<T>::value) // only for floating point types
        {
            if (std::isinf(result - decrement))
            {
                underflowed = true;
                return result; // prevent underflow
            }
        }

        result -= decrement;
    }

    return result;
}


//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character.

template <typename T>
void test_overflow()
{
    // TODO: The add_numbers template function will overflow in the second method call
    //        You need to change the add_numbers method to:
    //        1. Detect when an overflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no overflow happened or
    //        4. Return something to tell test_overflow the addition failed
    //        NOTE: The add_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_overflow method to:
    //        1. Detect when an add_numbers failed
    //        2. Inform the user the overflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_overflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem.
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps;
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    bool overflowed = false;

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    T result = add_numbers<T>(start, increment, steps, overflowed);
    std::cout << +result << " | Overflow: " << (overflowed ? "true" : "false") << std::endl;

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1, overflowed);
    std::cout << +result << " | Overflow: " << (overflowed ? "true" : "false") << std::endl;
}

template <typename T>
void test_underflow()
{
    // TODO: The subtract_numbers template function will underflow in the second method call
    //        You need to change the subtract_numbers method to:
    //        1. Detect when an underflow will happen
    //        2. Prevent it from happening
    //        3. Return the correct value when no underflow happened or
    //        4. Return something to tell test_underflow the subtraction failed
    //        NOTE: The subtract_numbers method must remain a template in the NumericFunctions header.
    //
    //        You need to change the test_underflow method to:
    //        1. Detect when an subtract_numbers failed
    //        2. Inform the user the underflow happened
    //        3. A successful result displays the same result as before you changed the method
    //        NOTE: You cannot change anything between START / END DO NOT CHANGE
    //              The test_underflow method must remain a template in the NumericOverflows source file
    //
    //  There are more than one possible solution to this problem.
    //  The solution must work for all of the data types used to call test_overflow() in main().

    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    bool underflowed = false;

    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    T result = subtract_numbers<T>(start, decrement, steps, underflowed);
    std::cout << +result << " | Underflow: " << (underflowed ? "true" : "false") << std::endl;

    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1, underflowed);
    std::cout << +result << " | Underflow: " << (underflowed ? "true" : "false") << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

int main()
{
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    do_overflow_tests(star_line);
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}